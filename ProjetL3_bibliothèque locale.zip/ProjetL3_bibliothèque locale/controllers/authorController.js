const Author = require('../models/author');

// Affiche la liste de tous les auteurs
exports.author_list = function(req, res) {
    Author.find()
        .sort([['family_name', 'ascending']])
        .exec(function (err, list_authors) {
            if (err) { return next(err); }
            res.render('author_list', { title: 'Author List', author_list: list_authors });
        });
};

// Affiche le formulaire de création d'un auteur sur GET
exports.author_create_get = function(req, res) {
    res.render('author_form', { title: 'Create Author' });
};

// Gère la création d'un auteur sur POST
exports.author_create_post = function(req, res) {
    const author = new Author({
        first_name: req.body.first_name,
        family_name: req.body.family_name,
        date_of_birth: req.body.date_of_birth,
        date_of_death: req.body.date_of_death
    });
    author.save(function (err) {
        if (err) { return next(err); }
        res.redirect(author.url);
    });
};
