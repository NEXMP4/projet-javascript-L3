const Book = require('../models/book');

// Affiche la liste de tous les livres
exports.book_list = function(req, res) {
    Book.find({}, 'title author')
        .populate('author')
        .exec(function (err, list_books) {
            if (err) { return next(err); }
            res.render('book_list', { title: 'Book List', book_list: list_books });
        });
};

// Affiche le formulaire de création d'un livre sur GET
exports.book_create_get = function(req, res) {
    res.render('book_form', { title: 'Create Book' });
};

// Gère la création d'un livre sur POST
exports.book_create_post = function(req, res) {
    // Crée un objet livre avec des données échappées et ajustées
    const book = new Book({
        title: req.body.title,
        author: req.body.author,
        summary: req.body.summary,
        isbn: req.body.isbn,
        genre: req.body.genre
    });
    book.save(function (err) {
        if (err) { return next(err); }
        res.redirect(book.url);
    });
};
