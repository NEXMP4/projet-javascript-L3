const express = require('express');
const mongoose = require('mongoose');
const path = require('path');

// Créez une instance de l'application Express
const app = express();

// Connectez-vous à votre base de données MongoDB
mongoose.connect('mongodb://localhost:27017/local_library', { useNewUrlParser: true, useUnifiedTopology: true });

// Configurez mongoose pour utiliser les promesses globales
mongoose.Promise = global.Promise;

// Vérifiez la connexion à la base de données
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));

app.set('views', path.join(__dirname, 'views')); // Définir le dossier des vues
app.set('view engine', 'ejs'); // Dire a express que les vues sont en .ejs

// Utilisez Express pour analyser le corps des requêtes
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Importez vos routeurs ici
const bookRouter = require('./routes/bookRoutes');
const authorRouter = require('./routes/authorRoutes');

// Utilisez les routeurs avec leurs chemins de base respectifs
app.use('/books', bookRouter);
app.use('/authors', authorRouter);

// Gérez les requêtes à la racine
app.get('/', (req, res) => {
  res.render('index', { title: 'Bienvenue à la bibliothèque locale' });
});

// Démarrez le serveur
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Serveur en cours d'exécution sur le port ${PORT}`);
});