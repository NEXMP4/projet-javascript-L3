const express = require('express');
const router = express.Router();

// Importez le contrôleur d'auteur ici
const authorController = require('../controllers/authorController');

// Définissez des routes spécifiques pour les auteurs ici
router.get('/', authorController.author_list);
router.get('/create', authorController.author_create_get);
router.post('/create', authorController.author_create_post);

module.exports = router;
