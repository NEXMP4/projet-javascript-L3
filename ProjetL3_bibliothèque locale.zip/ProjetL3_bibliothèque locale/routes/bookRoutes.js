const express = require('express');
const router = express.Router();

// Importez le contrôleur de livre ici
const bookController = require('../controllers/bookController');

// Définissez des routes spécifiques pour les livres ici
router.get('/', bookController.book_list);
router.get('/create', bookController.book_create_get);
router.post('/create', bookController.book_create_post);

module.exports = router;
